
public class Officina {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Automobile auto1 = new Automobile("Ferrari", 4200, "AD 27 AM", 300000, "Rosso", 8);
		Automobile auto2 = new Automobile("Lamborghini", 4200, "CC 20 DD", 400000, "Blu", 7);
		Automobile auto3 = new Automobile("Maserati", 4200, "EE 21 FF", 200000, "Verde", 6);
		Automobile auto4 = new Automobile("Pagani", 4200, "GG 22 HH", 500000, "Grigio", 9);
		Automobile auto5 = new Automobile("Bugatti", 4200, "II 23 LL", 600000, "Viola", 10);

		Automobile [] auto = { auto1, auto2, auto3, auto4, auto5 };
		
		infoMacchinaPiùCostosa(auto);
		
		infoMacchina(auto, "AD 27 AM");		

		infoMacchinaColore(auto, "Viola");
		
	}

	static void infoMacchinaPiùCostosa(Automobile [] auto) {
		
		Automobile autoLusso = auto[0];
		
		for(int i = 0; i < auto.length; i++) {
			if(auto[i].getValore() > autoLusso.getValore()) {
			autoLusso = auto[i];	
			}
		} autoLusso.stampaInformazioni();
	}
	
	static void infoMacchina(Automobile [] auto, String targa) {
		
		Automobile autoTarga = null;
		
		for(int i = 0; i < auto.length; i++) {
			if(auto[i].getTarga().toUpperCase().equals(targa.toUpperCase())) {
				autoTarga = auto[i];	
			}
		} autoTarga.stampaInformazioni();
	}
	
	static void infoMacchinaColore(Automobile [] auto, String colore) {
		
		Automobile autoColore = null;
		
		for(int i = 0; i < auto.length; i++) {
			if(auto[i].getColore().toUpperCase().equals(colore.toUpperCase())) {
				autoColore = auto[i];	
			}
		} autoColore.stampaInformazioni();
	}
	
	
	
}
