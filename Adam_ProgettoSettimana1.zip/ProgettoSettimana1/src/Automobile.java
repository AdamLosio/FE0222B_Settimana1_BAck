
public class Automobile {

	//Proprietà
	private String nome;
	private int cilindrata;
	private String targa;
	private int prezzo;
	private String colore;
	private int numeroMarce;
	private boolean motoreAcceso;
	private int marcia;
	
	Automobile(String nome, int cilindrata, String targa, int prezzo, String colore, int numeroMarce){
		this.nome = nome;
		this.cilindrata = cilindrata;
		this.targa = targa;
		this.prezzo = prezzo;
		this.colore = colore;
		this.numeroMarce = numeroMarce;
		
		//Per tutte
		this.motoreAcceso = false;
		this.marcia = 0;
	}
	
	
	
	void accendiMotore(){
		this.motoreAcceso=true;
	}
	
	void spegniMotore(){
		this.motoreAcceso=false;
		this.marcia = 0;
	}
	
	void cambiaMarcia(int marcia ) {

	if (marcia>=0 && marcia<=this.numeroMarce) {
		this.marcia = marcia;
	}}
	
	void scalaMarcia() {
		if(this.marcia > 0) {
			this.marcia-- ;
		}			System.out.println("Errore nel decremento della marcia");

	}
	
	void aumentaMarcia() {
		if(this.marcia < this.numeroMarce) {
			this.marcia++ ;
		}else {
		System.out.println("Errore nel incremento della marcia");
		}
	}
	
	int getValore() {
		return this.prezzo;
	}
	
	String getTarga() {
		return this.targa;
	}
	String getColore() {
		return this.colore;
	}
	
	void stampaInformazioni() {
		
		System.out.println("nome: " + this.nome +  "cilindrata: " + this.cilindrata +
				"targa: " + this.targa + "prezzo: " + this.prezzo + "colore: " + this.colore);
		
		System.out.println("numero marce:" + this.numeroMarce + "motore acceso: " + this.motoreAcceso + "marcia:" +this.marcia);
	}
	
	
	
	} //ultima graffa

